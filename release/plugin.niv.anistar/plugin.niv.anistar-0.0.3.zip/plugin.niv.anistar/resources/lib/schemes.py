playlist_scheme = {
    'title': '',
	'media_id': '',
	'image': '',
	'other_hd': '',
	'other_2': '',
	'type_dub': '',
	'cdn': '',
	'to_skeep_ad': '',
	'viewing': 'false',
    'file': '',
	'file_h': ''
    }
