# -*- coding: utf-8 -*-
import sys

def clean_list(data):
    clean_list = ['\n', '\t', '\r', '\v', '\f', '  ']
    for value in clean_list:
        data = data.replace(value, '')
    return data
    
def rep_list(data):
    # rep_list = [('&amp;', '&'), ('&laquo;', '"'), ('&raquo;', '"'), ('&nbsp;', ' '), ('&mdash;', '-'), ('&ndash;', '-'),
    #             ('&hellip;', '...'), ('&copy;', '©'), ('&quot;', '"'), ('&apos;', '\''), ('&gt;', '>'), ('&lt;', '<'),
    #             ('&#8217;', '\''), ('&#8220;','“'), ('&#8221;','”'), ('&#039;', '\''), ('&#34;', '"'), ('&#39;', '\''), 
    #             ('‑', '-'), ('&ldquo;', '"'), ('&rdquo;', '"')]
    rep_list = [('&#8748;',' '), ('&#9651;',' '),('&#9734;',' '),('&#9733;',' '),('&#9825;',' '),('&#333;','o'),
                ('&#215;', 'x'), ('&#8734;', ''), ('&nbsp;', ' '), ('&#8537;', ' '), ('&#9829;', ' '), ('&#936;', ''),
                ('&#252;', 'u'), ('&#215;', ''), ('&#363;', 'u'), ('&#249;', 'u'), ('[email&#160;protected]', 'Idolmaster'),
                ('„', '"'), ('“', '"'), ('&copy;', '©'), ('&nbsp;', ' '), ('&raquo;', '')
                ]
    for value in rep_list:
        data = data.replace(value[0], value[1])
    return data

def tag_list(data):
    start = data.find('<')
    end = data.find('>')
    while start < end and start > -1:
        data = data.replace(data[start:end+1], '').strip()
        start = data.find('<')
        end = data.find('>')
    return data