# **LostFilm.tv**

- **Плагин**: для медиацентра **KODI** и систем основанных на KODI
- **Возможности**: Видео-просмотр торрент файлов (без выгрузки на ПК)
- **Версии KODI**: 18, 19, 20, 21
- **Система**: Любая (win, linux, android)
- **Требования**: Обязательная Авторизация
- **Разблокировка**: Для Зеркал Не требуется (зеркала используются по умолчанию)
____

**Рекомендуемый способ просмотра для Торрентов**:

- **ТАМ** 
- **TorrServer**
- **Elementum**
____
**Плагин можно установить:**
- из [Репозитория Search.db](https://github.com/seppius-xbmc-repo/ru/tree/master/repository.search.db)
- из [Репозитория NIV](https://github.com/NIV82/kodi_repo/tree/main/release/repository.niv)
- отдельно zip файлом через пункт "Установить из zip файла" [Для всех версий Kodi](https://github.com/NIV82/kodi_repo/tree/main/release/plugin.niv.lostfilm)

**выбирать последнюю версию - zip файл**
