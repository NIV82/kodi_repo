# -*- coding: utf-8 -*-

import os
import tempfile
import sys

import xbmc
import xbmcaddon
import pyxbmct

import xbmcgui
import time

import network

def data_print(data):
    xbmc.log(str(data), xbmc.LOGFATAL)


_addon = xbmcaddon.Addon(id='plugin.niv.lostfilm')
_addon_path = _addon.getAddonInfo('path')
_needcaptcha = False


class AuthModule(pyxbmct.AddonDialogWindow):
    
    def __init__(self, title=''):
        super(AuthModule, self).__init__(title)
        self.setGeometry(600, 250, 4, 2)
        self.set_auth_controls()
        self.set_navigation()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def set_auth_controls(self):
        login_label = pyxbmct.Label(u'Логин:')
        self.placeControl(login_label, 0, 0)
        self.login = pyxbmct.Edit('')
        self.placeControl(self.login, 0, 1)
        self.login.setText(_addon.getSetting('username'))
        #
        password_label = pyxbmct.Label(u'Пароль:')
        self.placeControl(password_label, 1, 0)
        self.password = pyxbmct.Edit('')
        self.placeControl(self.password, 1, 1)
        self.password.setText(_addon.getSetting('password'))
        #
        # if _need_captcha():
        #     self.image = pyxbmct.Image(_get_captcha())
        # else:
        #     self.image = pyxbmct.Image('')

        if _needcaptcha:     
            #self.image = pyxbmct.Image(_get_captcha())   
            self.image = pyxbmct.Image(os.path.join(_addon_path, 'bbb-splash.jpg'))
            self.placeControl(self.image, 2, 0, 1, 1)
            self.captcha = pyxbmct.Edit('')
            self.placeControl(self.captcha, 2, 1)
        #
        self.authorization_button = pyxbmct.Button(u'Авторизация')
        self.placeControl(self.authorization_button, 3, 0)
        self.close_button = pyxbmct.Button(u'Закрыть')
        self.placeControl(self.close_button, 3, 1)

    def set_navigation(self):
        if _needcaptcha:
            self.close_button.controlUp(self.captcha)
            self.close_button.controlDown(self.login)
            self.close_button.controlLeft(self.authorization_button)
            self.close_button.controlRight(self.authorization_button)
            #
            self.authorization_button.controlLeft(self.close_button)
            self.authorization_button.controlRight(self.close_button)
            #
            self.captcha.controlUp(self.password)
            self.captcha.controlDown(self.close_button)
            #
            self.password.controlUp(self.login)
            self.password.controlDown(self.captcha)
            #
            self.login.controlUp(self.close_button)
            self.login.controlDown(self.password)
            #
            self.setFocus(self.close_button)
        else:
            self.close_button.controlUp(self.password)
            self.close_button.controlDown(self.login)
            self.close_button.controlLeft(self.authorization_button)
            self.close_button.controlRight(self.authorization_button)
            #
            self.authorization_button.controlLeft(self.close_button)
            self.authorization_button.controlRight(self.close_button)
            #
            self.password.controlUp(self.login)
            self.password.controlDown(self.close_button)
            #
            self.login.controlUp(self.close_button)
            self.login.controlDown(self.password)
            #
            self.setFocus(self.close_button)

    def onControl(self, control):

        if control == self.authorization_button:
            progress = xbmcgui.DialogProgress()
            progress.create(u'Диалог хода выполнения:')
            for i in range(0, 100, 5):
                progress.update(i, u'{}\n{}'.format(self.login.getText(), self.password.getText()))

                
                #progress_bg.update(int(i), u'Загружено: {} из {} Mb'.format('{:.2f}'.format(bytes_read/1024/1024.0), '{:.2f}'.format(file_size/1024/1024.0)))
                time.sleep(0.2)

        if control == self.close_button:
            self.close()

    def setAnimation(self, control):
        # Set fade animation for all add-on window controls
        control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])


def _site_url():
    current_mirror = 'mirror_{}'.format(_addon.getSetting('mirror_mode'))
    current_url = _addon.getSetting(current_mirror)
    return current_url
        
def _need_captcha():
    site_url = _site_url()

    url = '{}/login'.format(site_url)
    html = network.get_web(url=url)

    need_captcha = html[html.rfind('name="need_captcha"'):]
    need_captcha = need_captcha[:need_captcha.find('>')]

    if 'name="need_captcha" value="1"' in need_captcha:
        return True
    else:
        return False
    
def _get_captcha():
    filename = tempfile.gettempdir() + '/captcha'
    captcha_url = '{}simple_captcha.php'.format(_site_url())

    data = network.get_web(url=captcha_url, bytes=True)

    with open(filename, 'wb') as write_file:
        write_file.write(data)

    return filename

def authorization_start():
    window = AuthModule(u'LostFilm Авторизация')
    window.doModal()
    del window
    
    return
# if __name__ == '__main__':
#     window = AuthModule(u'LostFilm Авторизация')
#     window.doModal()
#     # Destroy the instance explicitly because
#     # underlying xbmcgui classes are not garbage-collected on exit.
#     del window