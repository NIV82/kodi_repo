# -*- coding: utf-8 -*-

import os
import tempfile
import sys
import time
import random

import xbmc
import xbmcaddon
import pyxbmct
import xbmcgui
import xbmcvfs

from network import get_web


# act: users
# type: login
# mail: nikonorov.igor%40hotmail.com
# pass: 8675309
# need_captcha: 1
# captcha: 50543
# rem: 1

#act=users&type=login&mail=nikonorov.igor%2540hotmail.com&pass=8675309&need_captcha=1&captcha=90908&rem=1
#act=users&type=login&mail=nikonorov.igor%40hotmail.com&pass=8675309&need_captcha=1&captcha=88313&rem=1

def data_print(data):
    xbmc.log(str(data), xbmc.LOGFATAL)

_addon = xbmcaddon.Addon(id='plugin.niv.lostfilm')

try:
    addon_data_dir = xbmcvfs.translatePath(_addon.getAddonInfo('profile'))
    icon = xbmcvfs.translatePath(_addon.getAddonInfo('icon'))
    #fanart = xbmcvfs.translatePath(addon.getAddonInfo('fanart'))
    #plugin_dir = xbmcvfs.translatePath('special://home/addons/plugin.niv.lostfilm')
except:
    from utility import fs_enc
    addon_data_dir = fs_enc(xbmc.translatePath(_addon.getAddonInfo('profile')))
    icon = fs_enc(xbmc.translatePath(_addon.getAddonInfo('icon')))
    #fanart = fs_enc(xbmc.translatePath(addon.getAddonInfo('fanart')))
    #plugin_dir = fs_enc(xbmc.translatePath('special://home/addons/plugin.niv.lostfilm'))

#_addon_path = _addon.getAddonInfo('path')
#_sid_file = os.path.join(addon_data_dir, 'lostfilm.sid')

dialog = xbmcgui.Dialog()

try:
    from urllib import urlencode
    # from urllib import quote
    # from urllib import unquote
    from urllib import urlopen
    # from urlparse import parse_qs
    # import HTMLParser
    # unescape = HTMLParser.HTMLParser().unescape
except:
    from urllib.parse import urlencode
    # from urllib.parse import quote
    # from urllib.parse import unquote
    from urllib.request import urlopen
    # from urllib.parse import parse_qs
    # from html import unescape

class AuthModule(pyxbmct.AddonDialogWindow):
    def __init__(self, title=''):
        super(AuthModule, self).__init__(title)
        self.setGeometry(600, 240, 4, 2)
        self.set_auth_controls()
        self.set_navigation()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def set_auth_controls(self):
        login_label = pyxbmct.Label(u'Логин:')
        self.placeControl(login_label, 0, 0)
        self.login = pyxbmct.Edit('')
        self.placeControl(self.login, 0, 1)
        self.login.setText(_addon.getSetting('username'))
        #
        password_label = pyxbmct.Label(u'Пароль:')
        self.placeControl(password_label, 1, 0)
        self.password = pyxbmct.Edit('')
        self.placeControl(self.password, 1, 1)
        self.password.setText(_addon.getSetting('password'))
        #
        self.captcha_image = pyxbmct.Image('')
        _addon.setSetting('need_captcha','false')

        if _need_captcha():
            self.captcha_image = pyxbmct.Image(_get_captcha())
            _addon.setSetting('need_captcha','true')

        self.placeControl(self.captcha_image, 2, 0, 1, 1)
        self.captcha = pyxbmct.Edit('')
        self.placeControl(self.captcha, 2, 1)
        #
        self.authorization_button = pyxbmct.Button(u'Авторизация')
        self.placeControl(self.authorization_button, 3, 0)
        self.close_button = pyxbmct.Button(u'Закрыть')
        self.placeControl(self.close_button, 3, 1)

    def set_navigation(self):
        self.close_button.controlUp(self.captcha)
        self.close_button.controlDown(self.login)
        self.close_button.controlLeft(self.authorization_button)
        self.close_button.controlRight(self.authorization_button)
        #
        self.authorization_button.controlLeft(self.close_button)
        self.authorization_button.controlRight(self.close_button)
        #
        self.captcha.controlUp(self.password)
        self.captcha.controlDown(self.close_button)
        #
        self.password.controlUp(self.login)
        self.password.controlDown(self.captcha)
        #
        self.login.controlUp(self.close_button)
        self.login.controlDown(self.password)
        #
        self.setFocus(self.close_button)

    def onControl(self, control):

        if control == self.authorization_button:

            if not self.login.getText() or not self.password.getText():
                dialog.notification(heading='LostFilm', message='Введите Логин и Пароль', icon=icon, time=1000, sound=False)
            else:
                _addon.setSetting('username', self.login.getText())
                _addon.setSetting('password', self.password.getText())
                _addon.setSetting('captcha', self.captcha.getText())

            
                _auth_result = _create_authorization()
                # data_print('=============================')
                # data_print(_auth_result)
                self.close()

                # data_print(_auth_result)
                # data_print('=============================')

                # progress = xbmcgui.DialogProgress()
                # progress.create(u'Диалог хода выполнения:')

                
                # for i in range(0, 100, 5):
                #     progress.update(i, u'Авторизация: {}'.format(_auth_result))

                    
                #     #progress_bg.update(int(i), u'Загружено: {} из {} Mb'.format('{:.2f}'.format(bytes_read/1024/1024.0), '{:.2f}'.format(file_size/1024/1024.0)))
                #     time.sleep(0.2)

        if control == self.close_button:
            self.close()

    def setAnimation(self, control):
        # Set fade animation for all add-on window controls
        control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=500',),
                                ('WindowClose', 'effect=fade start=100 end=0 time=500',)])


def _site_url():
    current_mirror = 'mirror_{}'.format(_addon.getSetting('mirror_mode'))
    current_url = _addon.getSetting(current_mirror)
    return current_url
        
def _need_captcha():
    site_url = _site_url()

    url = '{}/login'.format(site_url)
    html = get_web(url=url)

    need_captcha = html[html.rfind('name="need_captcha"'):]
    need_captcha = need_captcha[:need_captcha.find('>')]

    if 'name="need_captcha" value="1"' in need_captcha:
        return True
    else:
        return False
    
def _get_captcha():
    filename = tempfile.gettempdir() + '/captcha'
    # captcha_url = '{}simple_captcha.php?{}'.format(_site_url(), random.random())
    captcha_url = '{}simple_captcha.php'.format(_site_url())
    #data_print(captcha_url)

    data = get_web(url=captcha_url, bytes=True)

    with open(filename, 'wb') as write_file:
        write_file.write(data)

    return filename

# def _get_captcha():
#     #captcha_url = '{}simple_captcha.php'.format(_site_url())
#     #captcha_url = '{}simple_captcha.php?{}'.format(_site_url(), random.random())

#     return captcha_url

def _proxy_data():
    if '0' in _addon.getSetting('unblock'):
        return None
        
    if '2' in _addon.getSetting('unblock'):
        proxy_data = {'https': _addon.getSetting('unblock_2')}
        return proxy_data

    pac_url = _addon.getSetting('unblock_1')

    try:
        proxy_time = float(_addon.getSetting('proxy_time'))
    except:
        proxy_time = 0

    if time.time() - proxy_time > 604800:
        _addon.setSetting('proxy_time', str(time.time()))
        proxy_pac = urlopen(pac_url).read()

        try:
            proxy_pac = str(proxy_pac, encoding='utf-8')
        except:
            pass
#
        proxy = proxy_pac[proxy_pac.find('PROXY ')+6:proxy_pac.find('; DIRECT')].strip()
        _addon.setSetting('proxy', proxy)
        proxy_data = {'https': proxy}
    else:
        if _addon.getSetting('proxy'):
            proxy_data = {'https': _addon.getSetting('proxy')}
        else:
            proxy_pac = urlopen(pac_url).read()
                
            try:
                proxy_pac = str(proxy_pac, encoding='utf-8')
            except:
                pass

            proxy = proxy_pac[proxy_pac.find('PROXY ')+6:proxy_pac.find('; DIRECT')].strip()
            _addon.setSetting('proxy', proxy)
            proxy_data = {'https': proxy}

    return proxy_data


def _create_authorization():
    # if not _addon.getSetting('username') or not _addon.getSetting('password'):
    #     self.params['mode'] = 'addon_setting'
    #     dialog.notification(heading='LostFilm', message='Введите Логин и Пароль', icon=icon, time=1000, sound=False)
    #     return
    need_captcha = ''
    if 'true' in _addon.getSetting('need_captcha'):
        need_captcha = '1'

    from network import WebTools
    network = WebTools(
        auth_usage=True,
        auth_status=bool(_addon.getSetting('auth') == 'true'),
        proxy_data = _proxy_data())
    network.auth_post_data = urlencode({
        "act": "users", 
        "type": "login", 
        "mail": _addon.getSetting('username'), 
        "pass": _addon.getSetting('password'), 
        "need_captcha": need_captcha,
        "captcha": _addon.getSetting('captcha'),
        "rem": "1"})
    # network.auth_post_data = 'act=users&type=login&mail=nikonorov.igor%2540hotmail.com&pass=8675309&need_captcha=1&captcha={}&rem=1'.format(
    #     _addon.getSetting('captcha')
    # )
    network.auth_url = '{}ajaxik.users.php'.format(_site_url())
    network.sid_file = os.path.join(addon_data_dir, 'lostfilm.sid')
    del WebTools

    try:
        temp_session = float(_addon.getSetting('auth_session'))
    except:
        temp_session = 0
        
    if time.time() - temp_session > 604800:
        _addon.setSetting('auth_session', str(time.time()))
            
        try:
            os.remove(os.path.join(addon_data_dir, 'lostfilm.sid'))
        except:
            pass
            
        _addon.setSetting('auth', 'false')
        _addon.setSetting('user_session', '')

    authorization = network.authorization()

    if not authorization:
        dialog.notification(heading='Авторизация', message='Проверьте Логин и Пароль', icon=icon, time=1000, sound=False)
        # window = AuthModule(u'Авторизация')
        # window.doModal()
        # del window

        dialog.notification(heading='Авторизация', message='Проверьте Логин и Пароль', icon=icon, time=1000, sound=False)
        return
    else:
        _addon.setSetting('auth', str(authorization).lower())

    if authorization:
        if not _addon.getSetting('user_session'):
            url = '{}my'.format(_site_url())
            html = network.get_html(url=url)
                
            user_session = html[html.find('session = \'')+11:html.find('UserData.newbie')]
            user_session = user_session[:user_session.rfind('\'')]
            user_session = user_session.strip()

            _addon.setSetting('user_session', user_session)

    return authorization

def authorization_start():
    if not _addon.getSetting('username') or not _addon.getSetting('password'):
        window = AuthModule(u'Авторизация')
        window.doModal()
        del window

    if 'false' in _addon.getSetting('auth'):
        window = AuthModule(u'Авторизация')
        window.doModal()
        del window

    return
