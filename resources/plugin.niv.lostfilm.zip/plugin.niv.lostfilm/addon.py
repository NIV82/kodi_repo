# -*- coding: utf-8 -*-

import os
import sys
import gc

import xbmcaddon

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'lib'))

_addon = xbmcaddon.Addon(id='plugin.niv.lostfilm')


if __name__ == '__main__':
    import authorization
    authorization.authorization_start()
    #import lostfilm
    #lostfilm.lostfilm_start()

gc.collect()