# -*- coding: utf-8 -*-

import os
import sys
import gc

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'lib'))

import anidub_t

if __name__ == "__main__":
    anidub_t.start()

gc.collect()