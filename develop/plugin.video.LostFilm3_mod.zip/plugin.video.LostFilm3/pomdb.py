# -*- coding: utf-8 -*-
import sys, os
import urllib, urllib2
from ftplib import FTP
temp_dir = "c:\\"

try:
	import xbmcaddon
	addon = xbmcaddon.Addon(id='plugin.video.LostFilm3')
	temp_dir = addon.getAddonInfo('path')
except:
	temp_dir = os.getcwd()


def ru(x):return unicode(x,'utf8', 'ignore')

def getURL_old(url,Referer = 'http://emulations.ru/'):
	#urllib2.install_opener(urllib2.build_opener())
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def getURL(url, Referer = 'http://emulations.ru/'):
	host=mfind(url,'//', '/')
	tail=mfind(url, host, '')
	import httplib
	conn = httplib.HTTPConnection(host)
	conn.request("GET", tail, headers={"User-Agent": 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60'})
	r1 = conn.getresponse()
	data = r1.read()
	conn.close()
	return data

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	if e=='': return r
	r2=r[:r.find(e)]
	return r2

def CRC32(buf):
		import binascii
		buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		return str("%08X" % buf)

def save_inf(s):
	p = os.path.join(ru(temp_dir),"temp.txt")
	f = open(p, "w")
	f.write(s)
	f.close()
	return p

def upload(ftp, path, ftp_path):
	with open(path, 'rb') as fobj:
		ftp.storbinary('STOR ' + ftp_path, fobj, 1024)


def get_path(id):
	HOST=get_host()['HOST']
	s='/lf/'+id+'.info'
	return s

#def make_id(ftp, id):
#	ret='/pom/'+id+'.info'
#	return ret
	
def make_id(ftp, id):
	s='/lf'
	i=id.split('/')
	for c in [i[0], i[1]]:
		s+='/'+c
		try:ftp.mkd(s)
		except: pass
	ret='/lf/'+id+'.info'
	print ret
	return ret


def verifid_id(ftp, id):
	try:size=ftp.size(get_path(id))
	except: size=0
	return size

def add(id, info):
	HUP=get_host()
	HOST=HUP['HOST']
	USER=HUP['USER']
	PASS=HUP['PASS']
	ftp = FTP(HOST)
	ftp.login(USER, PASS)
	print 'ADD DB: '+id
	dir=make_id(ftp, id)
	path = save_inf(repr(info))
	upload(ftp, path, dir)
	ftp.quit()

def get_info(id):
	if id == 'HOST': HOST = 'td-soft.narod.ru'
	else:            HOST=get_host()['HOST']
	url='http://'+HOST+'/lf/'+id+'.info'
	info=eval(getURL(url))
	return info

def get_host():
	return get_info('HOST')

#print get_info('540/1/1')